import 'package:get/get.dart';

class CommonController extends GetxController {
  static CommonController get to => Get.find();
  RxBool isSeller = false.obs;
}